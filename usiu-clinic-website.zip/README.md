# USIU Clinic | Campus Care Website

A responsive, multi-view static web application for **USIU Clinic**, allowing students and visitors to request appointments and view the anonymized public schedule.

## Project Structure

```text
usiu-clinic-website/
├── index.html   # Semantic HTML5 markup for all views (Home, Book, Appointments, Patient, Doctor, Admin, Login, Register)
├── style.css    # Responsive CSS3 styling, custom variables, and mobile navigation layout
├── script.js    # Interactive SPA routing, form validation, and schedule rendering
└── README.md    # Project documentation
```

## Deploying to GitHub Pages

1. Create a new repository on [GitHub](https://github.com/new) (e.g., `usiu-clinic-website`).
2. Upload `index.html`, `style.css`, `script.js`, and `README.md` directly into the root of the repository.
3. Go to your repository's **Settings** > **Pages**.
4. Under **Build and deployment**, set **Source** to **Deploy from a branch**, choose `main` (or `master`), and set the folder to `/ (root)`.
5. Click **Save**. Your live site will be published at `https://<your-username>.github.io/<repo-name>/` within a minute or two.

## Notes on Data Persistence

* Proprietary Canva SDK scripts from the prototype export were removed so the site runs cleanly on GitHub Pages without external dependency errors.
* Appointment requests submitted through the booking form are saved in the browser's `localStorage`, updating the **Appointments**, **Doctor view**, and **Admin view** metrics immediately.
